# Build guide for Windows

* build.bat - Build for all combos of: Win32,x64,Release,Debug using the current msbuild toolset
* package-zip.ps1 - Build zip package (using build.bat artifacts)

